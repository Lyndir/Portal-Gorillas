#import <UIKit/UIKit.h>

@class Sprite;

//CLASS INTERFACE
@interface AppController : NSObject <UIAccelerometerDelegate, UIAlertViewDelegate, UITextFieldDelegate, UIApplicationDelegate>
{
	UIWindow	*window;
}
@end

@interface TestDemo : Layer
{
}
-(NSString*) title;
@end

@interface Test1 : TestDemo
{}
@end

@interface Test2 : TestDemo
{}
@end

@interface Test3 : TestDemo
{}
@end

@interface Test4 : TestDemo
{}
@end

@interface Test5 : TestDemo
{}
@end

@interface Test6 : TestDemo
{}
@end
