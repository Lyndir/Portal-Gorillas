//
//  NSCharacterSet_Extensions.h
//  TouchJSON
//
//  Created by Jonathan Wight on 12/08/2005.
//  Copyright (c) 2005 Toxic Software. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCharacterSet (NSCharacterSet_Extensions)

+ (NSCharacterSet *)linebreaksCharacterSet;

@end
