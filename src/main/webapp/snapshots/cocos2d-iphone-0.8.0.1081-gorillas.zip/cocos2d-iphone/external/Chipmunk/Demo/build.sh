gcc -O3 -std=gnu99 -ffast-math ../src/cp*.c ../src/chipmunk.c ./*.c -I../src -lGL -lglut -o chipmunk_demos
