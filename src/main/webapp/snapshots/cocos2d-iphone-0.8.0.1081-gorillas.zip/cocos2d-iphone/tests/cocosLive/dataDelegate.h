//
//  dataDelegate.h
//  cocos2d-iphone
//
//  Created by Ricardo Quesada on 30/01/09.
//  Copyright 2009 Sapus Media. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface dataDelegate : NSObject <UITableViewDelegate, UITableViewDataSource>
{
}

@end
