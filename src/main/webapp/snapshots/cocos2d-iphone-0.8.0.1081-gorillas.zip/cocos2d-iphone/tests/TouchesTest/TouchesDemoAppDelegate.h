/* TouchesTest (c) Valentin Milea 2009
 */
#import <UIKit/UIKit.h>
#import "cocos2d.h"

@interface AppController : NSObject <UIApplicationDelegate>
{
	UIWindow *window;
}

@end
